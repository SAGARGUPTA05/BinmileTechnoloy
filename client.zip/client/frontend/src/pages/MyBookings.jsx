import { useEffect, useState } from "react";
import axios from "axios";
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";

export default function MyBookings() {
  const [bookings, setBookings] = useState([1,2,3]);

  useEffect(() => {
    axios.get("/api/my-bookings").then(res => setBookings(res.data));
  }, []);

  const handleDelete = (id) => {
    axios.delete(`/api/bookings/${id}`)
      .then(() => setBookings(bookings.filter(b => b.id !== id)));
  };

  const handleUpdate = (id, newStart, newEnd) => {
    axios.put(`/api/bookings/${id}`, { startTime: newStart, endTime: newEnd })
      .then(() => alert("Booking updated!"));
  };

  return (
    <div className="max-w-4xl mx-auto p-6">
      <h1 className="text-2xl font-semibold mb-6">My Bookings</h1>
      <div className="space-y-4">
        {bookings.map(booking => (
          <div key={booking.id} className="border border-appleBorder p-4 rounded-lg flex justify-between items-center">
            <div>
              <p className="font-medium">{booking.roomName}</p>
              <p className="text-appleGray text-sm">
                {new Date(booking.startTime).toLocaleString()} - {new Date(booking.endTime).toLocaleString()}
              </p>
            </div>
            <div className="flex items-center gap-3">
              <DatePicker
                selected={new Date(booking.startTime)}
                onChange={(date) => handleUpdate(booking.id, date, new Date(booking.endTime))}
                showTimeSelect
                dateFormat="Pp"
                className="border border-appleBorder p-2 rounded-lg"
              />
              <DatePicker
                selected={new Date(booking.endTime)}
                onChange={(date) => handleUpdate(booking.id, new Date(booking.startTime), date)}
                showTimeSelect
                dateFormat="Pp"
                className="border border-appleBorder p-2 rounded-lg"
              />
              <button onClick={() => handleDelete(booking.id)}
                className="bg-red-500 text-white px-3 py-2 rounded-lg hover:bg-red-600">
                Delete
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
