import axios from "axios";
import { createContext, useContext, useState } from "react";

const backend = "http://localhost:3000";
const UserContext = createContext();

export function UserContextProvider({ children }) {
  const [user, setUser] = useState({ id: "", name: "", position: "" });
  const [booking, setBooking] = useState([]);
  const [bookedRooms, setBookedRooms] = useState([]);
  const [showRoom,setShowRoom]=useState([]);
  const [emp,setEmp]=useState([])

  const addUser = async (data) => {
    try {
      const res = await axios.post(`${backend}/employees`, data);
      setUser(res.data);
      localStorage.setItem("user",JSON.stringify(res.data))
    } catch (err) {
      console.error("Error adding user:", err);
    }
  };

  const roomBooking = async (data) => {
    try {
      const res = await axios.post(`${backend}/bookings`,data);
      setBooking((prev) => [...prev, res.data]);
    } catch (err) {
      console.error("Error booking room:", err);
    }
  };

  const updateBooking = async (room_id, booking_id, start_time, end_time) => {
    try {
      const res = await axios.put(`${backend}/bookings/${booking_id}`, {
        room_id,
        start_time,
        end_time,
      });
      setBooking((prev) =>
        prev.map((b) => (b.id === booking_id ? res.data : b))
      );
    } catch (err) {
      console.error("Error updating booking:", err);
    }
  };

  const deleteBooking = async (booking_id) => {
    try {
      await axios.delete(`${backend}/bookings/${booking_id}`);
      setBooking((prev) => prev.filter((b) => b.id !== booking_id));
    } catch (err) {
      console.error("Error deleting booking:", err);
    }
  };
  const fetcRooms=async()=>{
    try {
      const res=await axios.get(`${backend}/get-room`);
      const data=res.data.rooms;
      setShowRoom(data )
      
    } catch (err) {
      console.error("Error fetching rooms:", err);
    }
  }
  const fetchEmployees=async()=>{
    try {
      const res=await axios.get(`${backend}/get-employee`);
      const data=res.data.rooms;
      setEmp(data )
      
    } catch (err) {
      console.error("Error fetching rooms:", err);
    }
  }
 const fetchBookedRoom = async () => {
  try {
    const res = await axios.get(`${backend}/bookings/rooms`);
    if (res.data) {
      setBookedRooms(res.data);
    } else {
      console.warn("No booked rooms found.");
      setBookedRooms([]);
    }
  } catch (err) {
    console.error("Error fetching booked rooms:", err.message);
    setBookedRooms([]); // reset on error
  }
};


  return (
    <UserContext.Provider
      value={{
        user,
        setUser,
        booking,
        setBooking,
        bookedRooms,
        setBookedRooms,
        addUser,
        roomBooking,
        fetcRooms,
        updateBooking,
        deleteBooking,
        showRoom,
        fetchBookedRoom,
        fetchEmployees,
        fetcRooms,
        emp
        

      }}
    >
      {children}
    </UserContext.Provider>
  );
}

export function useUserContext() {
  const context = useContext(UserContext);
  if (!context) {
    throw new Error("useUserContext must be used within a UserContextProvider");
  }
  return context;
}
